var weather;
var r;
var g;
var b;
var rslider = 0;
var gslider = 0;
var bslider = 0;

let capture;
let calendarTable; // object containing all of our data!
let newsTable;
let calendarTableTop = 100; // y-coordinate for top of table
let calendarTableBottom = 300; // y-coordinate for bottom of table
let newsTableTop = 850; // y-coordinate for top of table
let newsTableBottom = 900; // y-coordinate for bottom of table
let fontSize = 15;

function preload() {
  weather = loadJSON(
    "https://api.openweathermap.org/data/2.5/weather?q=lubbock&APPID=af2b9cf608567e0f30745c0bcc877730&units=imperial"
  );

  newsTable = loadTable("News.csv", "csv", "header");
  calendarTable = loadTable("Calendar.csv", "csv", "header");
}
function setup() {
  createCanvas(1700, 950);
  rslider = createSlider(0, 255, 0, 5);
  gslider = createSlider(0, 255, 0, 5);
  bslider = createSlider(0, 255, 0, 5);
  capture = createCapture(VIDEO);
  capture.hide();
  print(weather);
}

function draw() {
  //MIRROR
  background(0);
  image(capture, 0, 0, 1700, 950);

  //CLOCK
  fill(255);
  textFont("Futura", 40);
  text(
    month() + "/" + day() + "/" +
      year() +
      " " + nf(hour() % 12, 2) +
      ":" + nf(minute(), 2) +
      ":" +
      nf(second(), 2), 650, 75);

  //weather
  textSize(30);
  if (weather) {
    fill(255);
    text("WEATHER: ", 1400, 45)
    text("Temp: " + weather.main.temp + " F", 1400, 80);
    text("Feels Like: " + weather.main.feels_like + " F", 1400, 115);
    text("Min: " + weather.main.temp_min + " F", 1400, 150);
    text("Max: " + weather.main.temp_max + " F", 1400, 185);
  }

  //calendar
  let calendarRowCount = calendarTable.getRowCount();
  for (let r = 0; r < calendarRowCount; r++) {
    let y = map(r, 0, calendarRowCount - 1, calendarTableTop, calendarTableBottom);
    text(calendarTable.getString(r, "Time"), 20, y);
    text(calendarTable.get(r, "Meeting"), 180, y);
  }
  text("CALENDAR: ", 20, 45);

  //news
  let newsRowCount = newsTable.getRowCount();
  for (let r = 0; r < newsRowCount; r++) {
    let y = map(r, 0, newsRowCount - 1, newsTableTop, newsTableBottom);
    text(newsTable.getString(r, "Author"), 20, y);
    text(newsTable.get(r, "Description"), 250, y);
  }
  text("NEWS:", 20, 800);


  text("HEALTH: ", 1400, 800)
  text("Weight: 116 lbs", 1400, 850)


  var r = rslider.value();
  var g = gslider.value();
  var b = bslider.value();
  fill(r, g, b);
  ellipse(60, 510, 100, 100);
  ellipse(60, 620, 100, 100);
  ellipse(60, 400, 100, 100);

  ellipse(1620, 510, 100, 100);
  ellipse(1620, 620, 100, 100);
  ellipse(1620, 400, 100, 100);

}
